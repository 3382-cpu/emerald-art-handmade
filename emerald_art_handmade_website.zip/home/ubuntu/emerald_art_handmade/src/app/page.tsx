import React from 'react';
import Header from '@/components/Header'; // Import Header
import Footer from '@/components/Footer'; // Import Footer

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header /> {/* Use Header Component */}

      {/* Main Content */}
      <main className="flex-grow container mx-auto p-8">
        <h2 className="text-3xl font-semibold mb-6 text-center text-emerald-700">أهلاً بكم في Emerald Art Handmade</h2>
        <p className="text-lg text-gray-700 mb-8 text-center">
          نصنع لكم قطعاً فنية يدوية فريدة من نوعها، من استاندات الورد الأنيقة إلى المرايا المزخرفة. اكتشفوا إبداعاتنا!
        </p>
        {/* Placeholder for featured products or banner */}
        <div className="bg-gray-200 h-64 rounded-lg flex items-center justify-center mb-8 shadow">
          {/* Suggestion: Add a placeholder image here */}
          {/* <img src="/placeholder-banner.jpg" alt="Featured Products" className="object-cover w-full h-full rounded-lg"/> */}
          <p className="text-gray-500">مساحة لعرض صور مميزة أو أحدث المنتجات</p>
        </div>

        {/* Shipping Offer */}
        <div className="bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700 p-4 mb-8 rounded-r-lg shadow" role="alert">
          <p className="font-bold">✨ عرض خاص! ✨</p>
          <p>استمتع بشحن مجاني لجميع الطلبات لمدة أسبوع!</p>
        </div>

        {/* Add more sections like testimonials or gallery preview */}

      </main>

      <Footer /> {/* Use Footer Component */}
    </div>
  );
}

