"use client"; // Add this directive for client-side interactivity

import React, { useState } from 'react';
import Header from '@/components/Header'; // Import Header
import Footer from '@/components/Footer'; // Import Footer

// Placeholder product data - replace with actual data later
const initialProducts = [
  {
    id: 1,
    name: 'استاند ورد أنيق',
    description: 'استاند ورد مصنوع يدوياً بتصميم فريد.',
    price: 150,
    // IMPORTANT: Replace '/placeholder-image.jpg' with the actual path to your product image
    // Images should be placed in the /public directory (e.g., /public/images/stand1.jpg)
    // Then the path would be '/images/stand1.jpg'
    imageUrl: '/placeholder-image.jpg',
    availableColors: ['أحمر', 'أبيض', 'وردي', 'أصفر'],
  },
  {
    id: 2,
    name: 'مرآة مزخرفة',
    description: 'مرآة حائط مزخرفة يدوياً بلمسة فنية.',
    price: 250,
    imageUrl: '/placeholder-image.jpg', // Replace with actual image path
    availableColors: ['ذهبي', 'فضي', 'أسود'],
  },
  // Add more products here following the same structure
];

// Product Card Component
function ProductCard({ product, onCustomize }) {
  const [selectedColor, setSelectedColor] = useState(product.availableColors[0]);
  const [quantity, setQuantity] = useState(1);

  const handleColorChange = (event) => {
    setSelectedColor(event.target.value);
  };

  const handleQuantityChange = (event) => {
    const value = parseInt(event.target.value, 10);
    if (value > 0) {
      setQuantity(value);
    }
  };

  return (
    <div className="border rounded-lg p-4 shadow-md flex flex-col bg-white">
      {/* Make sure the image path in initialProducts is correct */}
      <img src={product.imageUrl} alt={product.name} className="w-full h-48 object-cover rounded-md mb-4" />
      <h3 className="text-xl font-semibold mb-2 text-emerald-700">{product.name}</h3>
      {/* Product description can be edited here */}
      <p className="text-gray-600 mb-4 flex-grow">{product.description}</p>
      <p className="text-lg font-bold mb-4 text-emerald-600">{product.price} درهم</p>

      {/* Customization Options */}
      <div className="mb-4">
        <label htmlFor={`color-${product.id}`} className="block text-sm font-medium text-gray-700 mb-1">اختر اللون:</label>
        <select
          id={`color-${product.id}`}
          value={selectedColor}
          onChange={handleColorChange}
          className="w-full p-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
        >
          {product.availableColors.map(color => (
            <option key={color} value={color}>{color}</option>
          ))}
        </select>
      </div>

      <div className="mb-4">
        <label htmlFor={`quantity-${product.id}`} className="block text-sm font-medium text-gray-700 mb-1">الكمية:</label>
        <input
          type="number"
          id={`quantity-${product.id}`}
          value={quantity}
          onChange={handleQuantityChange}
          min="1"
          className="w-full p-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
        />
      </div>

      {/* Add more customization like shape/number if needed */}

      <button
        // Note: Cart functionality is not implemented in this version.
        onClick={() => onCustomize(product, { color: selectedColor, quantity })}
        className="mt-auto bg-emerald-600 text-white py-2 px-4 rounded-md hover:bg-emerald-700 transition duration-300"
      >
        إضافة للسلة (قيد التطوير)
      </button>
    </div>
  );
}

// Products Page Component
export default function ProductsPage() {
  // To add/edit products, modify the 'initialProducts' array at the top of this file.
  const [products, setProducts] = useState(initialProducts);

  const handleCustomize = (product, customization) => {
    // Placeholder for adding to cart logic - currently shows an alert.
    console.log('Adding to cart:', product.name, customization);
    alert(`تمت إضافة ${customization.quantity} من ${product.name} باللون ${customization.color} (وظيفة السلة قيد التطوير)`);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header /> {/* Use Header Component */}

      {/* Main Content */}
      <main className="flex-grow container mx-auto p-8">
        <h2 className="text-3xl font-semibold mb-6 text-center text-emerald-700">منتجاتنا المصنوعة يدوياً</h2>

        {/* Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map(product => (
            <ProductCard key={product.id} product={product} onCustomize={handleCustomize} />
          ))}
        </div>
      </main>

      <Footer /> {/* Use Footer Component */}
    </div>
  );
}

