"use client"; // Add this directive for client-side interactivity

import React, { useState } from 'react';
import Header from '@/components/Header'; // Import Header
import Footer from '@/components/Footer'; // Import Footer

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitMessage('');

    // --- Placeholder for actual form submission logic --- 
    // In a real application, you would send this data to a backend API
    // or use a service like Formspree, Netlify Forms, etc.
    console.log('Form Data Submitted:', formData);
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500)); 
    // --- End Placeholder --- 

    // Simulate success
    setSubmitMessage('شكراً لتواصلك! سنقوم بالرد عليك في أقرب وقت ممكن.');
    setFormData({ name: '', email: '', message: '' }); // Clear form
    setIsSubmitting(false);

    // Simulate error (uncomment to test error handling)
    // setSubmitMessage('حدث خطأ أثناء إرسال الرسالة. يرجى المحاولة مرة أخرى.');
    // setIsSubmitting(false);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header /> {/* Use Header Component */}

      {/* Main Content */}
      <main className="flex-grow container mx-auto p-8">
        <h2 className="text-3xl font-semibold mb-6 text-center text-emerald-700">تواصل معنا</h2>
        <div className="max-w-2xl mx-auto bg-white shadow-md rounded-lg p-6">
          <p className="text-lg text-gray-700 mb-6 text-center">
            هل لديك أي استفسار أو طلب خاص؟ لا تتردد في التواصل معنا عبر النموذج أدناه أو باستخدام معلومات الاتصال.
          </p>

          {/* Contact Form */}
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">الاسم:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div className="mb-6">
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">رسالتك:</label>
              <textarea
                id="message"
                name="message"
                rows={5}
                value={formData.message}
                onChange={handleChange}
                required
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
              ></textarea>
            </div>
            <div className="text-center">
              <button
                type="submit"
                disabled={isSubmitting}
                className="bg-emerald-600 text-white py-2 px-6 rounded-md hover:bg-emerald-700 transition duration-300 disabled:opacity-50"
              >
                {isSubmitting ? 'جاري الإرسال...' : 'إرسال الرسالة'}
              </button>
            </div>
            {submitMessage && (
              <p className={`mt-4 text-center ${submitMessage.includes('خطأ') ? 'text-red-600' : 'text-green-600'}`}>
                {submitMessage}
              </p>
            )}
          </form>

          {/* Contact Info (Optional) */}
          <div className="mt-8 pt-6 border-t border-gray-200 text-center">
            <h3 className="text-xl font-semibold mb-2 text-emerald-700">معلومات الاتصال الأخرى</h3>
            {/* IMPORTANT: Replace placeholder email and phone with actual contact info */}
            <p className="text-gray-600">البريد الإلكتروني: <a href="mailto:info@example.com" className="text-emerald-600 hover:underline">info@example.com</a> (مثال)</p>
            <p className="text-gray-600">الهاتف: +971 XX XXX XXXX (مثال)</p>
            {/* Add social media links if available */}
          </div>
        </div>
      </main>

      <Footer /> {/* Use Footer Component */}
    </div>
  );
}

