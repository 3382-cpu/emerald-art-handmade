import React from 'react';
import Header from '@/components/Header'; // Import Header
import Footer from '@/components/Footer'; // Import Footer

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header /> {/* Use Header Component */}

      {/* Main Content */}
      <main className="flex-grow container mx-auto p-8">
        <h2 className="text-3xl font-semibold mb-6 text-center text-emerald-700">عن Emerald Art Handmade</h2>
        <div className="bg-white shadow-md rounded-lg p-6 max-w-4xl mx-auto">
          <p className="text-lg text-gray-700 mb-4">
            في Emerald Art Handmade، نؤمن بجمال الإبداع اليدوي وقوة التفاصيل الدقيقة. نحن متخصصون في صناعة قطع فنية فريدة تضفي لمسة من الأناقة والدفء على مساحاتكم.
          </p>
          <p className="text-lg text-gray-700 mb-4">
            بدأنا بشغف لصناعة استاندات الورد التي تعكس الذوق الرفيع، ثم توسعنا لنشمل تصميم المرايا المزخرفة وغيرها من الأعمال اليدوية التي تحمل بصمتنا الخاصة. كل قطعة نصنعها هي نتاج ساعات من العمل الدقيق والحب للتفاصيل، باستخدام أجود الخامات لضمان تقديم منتج لا مثيل له.
          </p>
          <p className="text-lg text-gray-700 mb-4">
            هدفنا هو أن نقدم لكم ليس فقط منتجاً، بل تجربة فنية تعبر عن شخصيتكم وتلبي تطلعاتكم. نفخر بتقديم خيارات تخصيص متعددة تتيح لكم المشاركة في تصميم القطعة التي تحلمون بها.
          </p>
          <p className="text-lg text-gray-700">
            شكراً لثقتكم في Emerald Art Handmade. نتطلع لخدمتكم وإضافة لمسة فنية إلى حياتكم.
          </p>
          {/* Placeholder for team image or workshop photo */}
          <div className="mt-8 bg-gray-200 h-48 rounded-lg flex items-center justify-center">
            {/* Suggestion: Add a placeholder image here */}
            {/* <img src="/placeholder-team.jpg" alt="Our Workshop" className="object-cover w-full h-full rounded-lg"/> */}
            <p className="text-gray-500">صورة للفريق أو ورشة العمل (اختياري)</p>
          </div>
        </div>
      </main>

      <Footer /> {/* Use Footer Component */}
    </div>
  );
}

