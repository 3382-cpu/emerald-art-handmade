import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white p-4 mt-auto">
      <div className="container mx-auto text-center">
        <p>&copy; {new Date().getFullYear()} Emerald Art Handmade. جميع الحقوق محفوظة.</p>
        {/* Add social media links or other info here if needed */}
      </div>
    </footer>
  );
}

