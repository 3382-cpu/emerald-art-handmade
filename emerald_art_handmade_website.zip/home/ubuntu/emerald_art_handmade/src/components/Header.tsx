import React from 'react';

export default function Header() {
  // Determine active page based on current URL path (implementation depends on routing library)
  // For simplicity, we'll pass the active page name as a prop for now.
  // A more robust solution would use Next.js's `usePathname` hook.

  // Placeholder for active page logic
  const pathname = typeof window !== 'undefined' ? window.location.pathname : '';

  return (
    <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow-md">
      <div className="container mx-auto flex flex-wrap justify-between items-center">
        <h1 className="text-2xl font-bold mb-2 sm:mb-0">
          <a href="/">Emerald Art Handmade</a>
        </h1>
        <nav>
          <ul className="flex space-x-4">
            <li><a href="/" className={`hover:text-emerald-200 ${pathname === '/' ? 'font-bold' : ''}`}>الرئيسية</a></li>
            <li><a href="/products" className={`hover:text-emerald-200 ${pathname === '/products' ? 'font-bold' : ''}`}>المنتجات</a></li>
            <li><a href="/about" className={`hover:text-emerald-200 ${pathname === '/about' ? 'font-bold' : ''}`}>من نحن</a></li>
            <li><a href="/contact" className={`hover:text-emerald-200 ${pathname === '/contact' ? 'font-bold' : ''}`}>اتصل بنا</a></li>
          </ul>
        </nav>
      </div>
      {/* Optional: Add the free shipping banner here if desired globally */}
      {/* <div className="bg-emerald-700 text-center py-1 text-sm">
        ✨ شحن مجاني لمدة أسبوع! ✨
      </div> */}
    </header>
  );
}

