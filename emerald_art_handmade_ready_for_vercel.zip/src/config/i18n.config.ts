// src/config/i18n.config.ts

// Define supported locales in a central place
export const locales = ["en", "ar"];

export const defaultLocale = "en";

