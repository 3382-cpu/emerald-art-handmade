// src/app/about/page.tsx
"use client";

import React from "react";
import { useTranslations } from "next-intl"; // Import hook

export default function AboutPage() {
  const t = useTranslations("AboutPage"); // Use translations

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-semibold text-center text-primary">{t("title")}</h1>
      <div className="bg-card p-6 rounded-lg shadow-md text-card-foreground max-w-3xl mx-auto">
        {/* Use dangerouslySetInnerHTML if the paragraph contains HTML or handle line breaks appropriately */}
        <p className="text-lg leading-relaxed whitespace-pre-line">
          {t("paragraph")}
        </p>
        {/* Add more details or images if needed */}
      </div>
    </div>
  );
}

