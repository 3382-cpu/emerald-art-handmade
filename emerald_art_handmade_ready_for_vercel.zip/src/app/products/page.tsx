// src/app/products/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import ProductCard from "@/components/ProductCard";
import { useTranslations, useLocale } from "next-intl"; // Import useLocale

// Define the structure of a product object
interface Product {
  id: number;
  name: string; // Name should come translated from API
  description: string; // Description should come translated from API
  price_usd: number;
  image_urls: string; // JSON string like ["url1", "url2"]
  available_colors: string; // JSON string like ["red", "blue"]
  category?: string;
}

export default function ProductsPage() {
  const t = useTranslations("ProductsPage"); // Use translations
  const locale = useLocale(); // Get current locale

  // State for products, fetched from API
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      setError(null);
      try {
        // Fetch products based on locale
        const response = await fetch(`http://localhost:5000/api/products?lang=${locale}`);
        if (!response.ok) {
          throw new Error(`Failed to fetch products (status: ${response.status})`);
        }
        const data = await response.json();
        if (Array.isArray(data)) {
            setProducts(data);
        } else {
            console.error("API did not return an array for products:", data);
            throw new Error("Invalid data format received from API");
        }
      } catch (err: any) {
        setError(err.message);
        setProducts([]);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, [locale]); // Re-fetch if locale changes

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-semibold text-center text-primary">{t("title")}</h1>

      {/* Optional: Add filters or sorting options here later */}

      {loading && <p className="text-center py-10">{t("loading")}</p>}
      {error && <p className="text-center py-10 text-destructive">{t("error", { error: error })}</p>}

      {!loading && !error && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}

      {!loading && !error && products.length === 0 && (
        <p className="text-center text-muted-foreground py-10">{t("noProducts")}</p>
      )}
    </div>
  );
}

