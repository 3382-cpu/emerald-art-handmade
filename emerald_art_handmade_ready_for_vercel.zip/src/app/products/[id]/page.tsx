// src/app/products/[id]/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import { useTranslations, useLocale } from "next-intl"; // Import hooks

// Define interfaces (assuming they are correct)
interface Product {
  id: number;
  name: string;
  description: string;
  price_usd: number;
  image_urls: string;
  available_colors: string;
  category?: string;
}

interface Review {
    id: number;
    user_id: number;
    product_id: number;
    rating: number;
    comment: string | null;
    created_at: string;
    // username?: string;
}

export default function ProductDetailPage() {
  const params = useParams();
  const productId = params.id;
  const t = useTranslations("ProductDetailPage"); // Use translations
  const locale = useLocale(); // Get current locale

  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (!productId) return;

    const fetchProductData = async () => {
      setLoading(true);
      setError(null);
      try {
        // Fetch product details based on locale
        const productRes = await fetch(`http://localhost:5000/api/products/${productId}?lang=${locale}`);
        if (!productRes.ok) {
          throw new Error(`Failed to fetch product (status: ${productRes.status})`);
        }
        const productData = await productRes.json();
        setProduct(productData);

        // Fetch product reviews (reviews are not typically translated)
        const reviewsRes = await fetch(`http://localhost:5000/api/products/${productId}/reviews`);
        if (!reviewsRes.ok) {
          console.error(`Failed to fetch reviews (status: ${reviewsRes.status})`);
        } else {
           const reviewsData = await reviewsRes.json();
           setReviews(reviewsData);
        }

      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProductData();
  }, [productId, locale]); // Re-fetch if ID or locale changes

  // Parse image URLs and colors safely
  let imageUrls: string[] = [];
  if (product?.image_urls) {
    try { imageUrls = JSON.parse(product.image_urls); } catch { /* Ignore */ }
  }
  let availableColors: string[] = [];
  if (product?.available_colors) {
    try {
      availableColors = JSON.parse(product.available_colors);
      if (availableColors.length > 0 && !selectedColor) {
        setSelectedColor(availableColors[0]);
      }
    } catch { /* Ignore */ }
  }

  const handleAddToCart = () => {
    // TODO: Implement Add to Cart logic
    console.log(`Add to cart: Product ID ${productId}, Quantity ${quantity}, Color ${selectedColor}`);
    alert("Add to Cart functionality not implemented yet.");
  };

  if (loading) {
    return <p className="text-center py-10">{t("loading")}</p>;
  }

  if (error) {
    return <p className="text-center py-10 text-destructive">{t("error", { error: error })}</p>;
  }

  if (!product) {
    return <p className="text-center py-10 text-muted-foreground">{t("notFound")}</p>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
        {/* Product Images */}
        <div>
          {imageUrls.length > 0 ? (
            <img
              src={imageUrls[0]}
              alt={product.name} // Alt text from API (assumed translated)
              className="w-full h-auto object-cover rounded-lg shadow-md border border-border"
            />
          ) : (
            <div className="w-full h-96 bg-muted rounded-lg flex items-center justify-center text-muted-foreground">
              No Image Available
            </div>
          )}
        </div>

        {/* Product Details & Actions */}
        <div className="space-y-4">
          <h1 className="text-3xl font-bold text-foreground">{product.name}</h1> {/* Name from API */} 
          <p className="text-2xl font-semibold text-primary">{t("price", { price: product.price_usd.toFixed(2) })}</p>
          <p className="text-muted-foreground leading-relaxed">{product.description}</p> {/* Description from API */} 

          {/* Color Selection */}
          {availableColors.length > 0 && (
            <div className="space-y-2">
              <label className="block text-sm font-medium text-foreground">{t("color")}</label>
              <div className="flex space-x-2">
                {availableColors.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`px-3 py-1 border rounded-md text-sm ${selectedColor === color ? "ring-2 ring-primary border-primary bg-secondary" : "border-input hover:border-foreground/50"}`}
                  >
                    {color} {/* Color names might need translation if not simple */} 
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity Selection */}
          <div className="space-y-2">
             <label htmlFor="quantity" className="block text-sm font-medium text-foreground">{t("quantity")}</label>
             <input
               type="number"
               id="quantity"
               name="quantity"
               min="1"
               value={quantity}
               onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
               className="w-20 px-3 py-1 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
             />
          </div>

          {/* Add to Cart Button */}
          <button
            onClick={handleAddToCart}
            className="w-full bg-primary text-primary-foreground px-8 py-3 rounded-md font-semibold hover:bg-primary/90 transition-colors text-lg"
          >
            {t("addToCart")}
          </button>

          {/* Shipping Info Snippet */}
          <p className="text-sm text-muted-foreground">{t("shippingInfo")}</p>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="mt-12 pt-8 border-t border-border">
        <h2 className="text-2xl font-semibold mb-6 text-foreground">{t("reviewsTitle")}</h2>
        {reviews.length > 0 ? (
          <div className="space-y-6">
            {reviews.map((review) => (
              <div key={review.id} className="bg-card p-4 rounded-lg shadow-sm border border-border/50">
                <div className="flex items-center mb-2">
                  {/* Stars */}
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className={`w-5 h-5 ${i < review.rating ? "fill-current" : "text-gray-300"}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  {/* TODO: Display username when available */}
                  {/* <span className="ml-3 text-sm font-medium text-foreground">{t("byUser", { id: review.user_id })}</span> */}
                </div>
                {review.comment && <p className="text-muted-foreground">{review.comment}</p>}
                <p className="text-xs text-muted-foreground/70 mt-2">{new Date(review.created_at).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">{t("noReviews")}</p>
        )}
        {/* TODO: Add Review Form component here later */}
      </div>
    </div>
  );
}

