// src/app/admin/orders/page.tsx
"use client";

import React, { useState, useEffect } from "react";
// import { useTranslations } from "next-intl"; // Add later
// import { useAuth } from "@/context/AuthContext"; // Add later for role checking

// Define Order interface (matching backend)
interface OrderItem {
    id: number;
    order_id: number;
    product_id: number;
    quantity: number;
    price_at_purchase: number;
    // product_name?: string; // Optional, if joined in backend
}

interface Order {
    id: number;
    user_id: number;
    status: string;
    total_amount_usd: number;
    shipping_address: string;
    created_at: string;
    updated_at: string;
    items: OrderItem[];
    // user_username?: string; // Optional, if joined in backend
}

export default function AdminOrdersPage() {
  // const t = useTranslations("AdminOrders"); // Add later
  // const { user, loading: authLoading } = useAuth(); // Add later

  // --- Placeholder for admin check ---
  const isAdmin = true; // Replace with actual role check
  const authLoading = false;
  // --- End Placeholder ---

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Possible order statuses (match backend enum/values)
  const orderStatuses = ["pending", "processing", "shipped", "delivered", "cancelled"];

  useEffect(() => {
    // Fetch orders from the backend API
    const fetchOrders = async () => {
      setLoading(true);
      setError(null);
      try {
        // TODO: Add authentication headers
        const response = await fetch(`http://localhost:5000/api/admin/orders`);
        if (!response.ok) {
          throw new Error(`Failed to fetch orders (status: ${response.status})`);
        }
        const data = await response.json();
        if (Array.isArray(data)) {
          setOrders(data);
        } else {
          throw new Error("Invalid data format received");
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (isAdmin) { // Only fetch if user is admin
        fetchOrders();
    }
  }, [isAdmin]);

  const handleStatusChange = async (orderId: number, newStatus: string) => {
    // Optimistically update the UI first (optional)
    // setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o));

    try {
      // TODO: Add authentication headers
      const response = await fetch(`http://localhost:5000/api/admin/orders/${orderId}/status`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!response.ok) {
        const data = await response.json();
        // Revert optimistic update if failed
        // fetchOrders(); // Or revert manually
        throw new Error(data.error || `Failed to update status (status: ${response.status})`);
      }

      // Update state with the confirmed new status from backend
      const updatedOrder = await response.json();
      setOrders(orders.map(o => o.id === orderId ? updatedOrder : o));
      alert("Order status updated successfully."); // TODO: Use notification system

    } catch (err: any) {
      setError(`Error updating status for order ${orderId}: ${err.message}`);
      alert(`Error updating status: ${err.message}`); // TODO: Use notification system
      // Consider reverting optimistic update here as well
    }
  };

  if (authLoading || loading) {
    return <p className="text-center py-10">Loading orders...</p>; // TODO: Translate
  }

  if (!isAdmin) {
    return <p className="text-center py-10 text-destructive">Access Denied.</p>; // TODO: Translate
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-primary">Manage Orders</h1> {/* TODO: Translate */}

      {error && <p className="text-center text-destructive">Error: {error}</p>} {/* TODO: Translate */}

      {/* Orders Table */}
      <div className="bg-card p-4 rounded-lg shadow-md border border-border overflow-x-auto">
        <table className="w-full text-sm text-left text-foreground">
          <thead className="text-xs text-muted-foreground uppercase bg-secondary">
            <tr>
              <th scope="col" className="px-6 py-3">Order ID</th>
              <th scope="col" className="px-6 py-3">User ID</th>
              <th scope="col" className="px-6 py-3">Date</th>
              <th scope="col" className="px-6 py-3">Total (USD)</th>
              <th scope="col" className="px-6 py-3">Status</th>
              <th scope="col" className="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.length > 0 ? (
              orders.map((order) => (
                <tr key={order.id} className="bg-card border-b border-border/50 hover:bg-muted/50">
                  <td className="px-6 py-4 font-medium">{order.id}</td>
                  <td className="px-6 py-4">{order.user_id}</td> {/* TODO: Show username? */}
                  <td className="px-6 py-4">{new Date(order.created_at).toLocaleDateString()}</td>
                  <td className="px-6 py-4">${order.total_amount_usd.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <select
                      value={order.status}
                      onChange={(e) => handleStatusChange(order.id, e.target.value)}
                      className="bg-background border border-input rounded-md px-2 py-1 text-xs focus:ring-primary focus:border-primary"
                    >
                      {orderStatuses.map(status => (
                        <option key={status} value={status}>{status}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-6 py-4">
                    {/* TODO: Add link to order details page */}
                    <button className="text-blue-600 hover:underline text-xs">View Details</button> {/* TODO: Translate */}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-muted-foreground">No orders found.</td> {/* TODO: Translate */}
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

