// src/app/admin/users/page.tsx
"use client";

import React, { useState, useEffect } from "react";
// import { useTranslations } from "next-intl"; // Add later
// import { useAuth } from "@/context/AuthContext"; // Add later for role checking

// Define User interface (matching backend)
interface User {
    id: number;
    username: string;
    email: string;
    role: string; // e.g., "customer", "admin"
    created_at: string;
    updated_at?: string;
}

export default function AdminUsersPage() {
  // const t = useTranslations("AdminUsers"); // Add later
  // const { user: adminUser, loading: authLoading } = useAuth(); // Add later

  // --- Placeholder for admin check ---
  const isAdmin = true; // Replace with actual role check
  const authLoading = false;
  // --- End Placeholder ---

  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Possible roles (match backend)
  const userRoles = ["customer", "admin"];

  useEffect(() => {
    // Fetch users from the backend API
    const fetchUsers = async () => {
      setLoading(true);
      setError(null);
      try {
        // TODO: Add authentication headers
        const response = await fetch(`http://localhost:5000/api/admin/users`);
        if (!response.ok) {
          throw new Error(`Failed to fetch users (status: ${response.status})`);
        }
        const data = await response.json();
        if (Array.isArray(data)) {
          setUsers(data);
        } else {
          throw new Error("Invalid data format received");
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (isAdmin) { // Only fetch if user is admin
        fetchUsers();
    }
  }, [isAdmin]);

  const handleRoleChange = async (userId: number, newRole: string) => {
    try {
      // TODO: Add authentication headers
      const response = await fetch(`http://localhost:5000/api/admin/users/${userId}/role`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ role: newRole }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || `Failed to update role (status: ${response.status})`);
      }

      // Update state with the confirmed new role
      const updatedUser = await response.json();
      setUsers(users.map(u => u.id === userId ? updatedUser : u));
      alert("User role updated successfully."); // TODO: Use notification system

    } catch (err: any) {
      setError(`Error updating role for user ${userId}: ${err.message}`);
      alert(`Error updating role: ${err.message}`); // TODO: Use notification system
    }
  };

  const handleDeleteUser = async (userId: number) => {
    if (!confirm(`Are you sure you want to delete user ID ${userId}? This cannot be undone.`)) { // TODO: Use a modal and translate
      return;
    }
    try {
      // TODO: Add authentication headers
      const response = await fetch(`http://localhost:5000/api/admin/users/${userId}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || `Failed to delete user (status: ${response.status})`);
      }
      // Remove user from state
      setUsers(users.filter(u => u.id !== userId));
      alert("User deleted successfully."); // TODO: Use a notification system
    } catch (err: any) {
      setError(err.message);
      alert(`Error deleting user: ${err.message}`); // TODO: Use a notification system
    }
  };


  if (authLoading || loading) {
    return <p className="text-center py-10">Loading users...</p>; // TODO: Translate
  }

  if (!isAdmin) {
    return <p className="text-center py-10 text-destructive">Access Denied.</p>; // TODO: Translate
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-primary">Manage Users</h1> {/* TODO: Translate */}

      {error && <p className="text-center text-destructive">Error: {error}</p>} {/* TODO: Translate */}

      {/* Users Table */}
      <div className="bg-card p-4 rounded-lg shadow-md border border-border overflow-x-auto">
        <table className="w-full text-sm text-left text-foreground">
          <thead className="text-xs text-muted-foreground uppercase bg-secondary">
            <tr>
              <th scope="col" className="px-6 py-3">User ID</th>
              <th scope="col" className="px-6 py-3">Username</th>
              <th scope="col" className="px-6 py-3">Email</th>
              <th scope="col" className="px-6 py-3">Role</th>
              <th scope="col" className="px-6 py-3">Member Since</th>
              <th scope="col" className="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.length > 0 ? (
              users.map((user) => (
                <tr key={user.id} className="bg-card border-b border-border/50 hover:bg-muted/50">
                  <td className="px-6 py-4 font-medium">{user.id}</td>
                  <td className="px-6 py-4">{user.username}</td>
                  <td className="px-6 py-4">{user.email}</td>
                  <td className="px-6 py-4">
                     <select
                      value={user.role}
                      onChange={(e) => handleRoleChange(user.id, e.target.value)}
                      className="bg-background border border-input rounded-md px-2 py-1 text-xs focus:ring-primary focus:border-primary"
                      // Disable changing own role or superadmin role if applicable
                      // disabled={user.id === adminUser?.id || user.role === 'superadmin'}
                    >
                      {userRoles.map(role => (
                        <option key={role} value={role}>{role}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-6 py-4">{new Date(user.created_at).toLocaleDateString()}</td>
                  <td className="px-6 py-4 flex space-x-2">
                    <button
                      onClick={() => handleDeleteUser(user.id)}
                      className="text-red-600 hover:underline text-xs"
                      // disabled={user.id === adminUser?.id} // Prevent deleting self
                    >
                      Delete {/* TODO: Translate */}
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-muted-foreground">No users found.</td> {/* TODO: Translate */}
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

