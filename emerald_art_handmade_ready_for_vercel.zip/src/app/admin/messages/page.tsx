// src/app/admin/messages/page.tsx
"use client";

import React, { useState, useEffect } from "react";
// import { useTranslations } from "next-intl"; // Add later
// import { useAuth } from "@/context/AuthContext"; // Add later for role checking

// Define Message interface (matching backend)
interface Message {
    id: number;
    sender_id: number | null; // Null for anonymous contact form messages
    receiver_id: number | null; // Usually admin (null?) or specific user
    subject: string | null;
    body: string;
    is_read: boolean;
    created_at: string;
    order_id: number | null;
    // Optional fields if joined in backend
    // sender_username?: string;
    // receiver_username?: string;
}

export default function AdminMessagesPage() {
  // const t = useTranslations("AdminMessages"); // Add later
  // const { user, loading: authLoading } = useAuth(); // Add later

  // --- Placeholder for admin check ---
  const isAdmin = true; // Replace with actual role check
  const authLoading = false;
  // --- End Placeholder ---

  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Fetch messages from the backend API
    const fetchMessages = async () => {
      setLoading(true);
      setError(null);
      try {
        // TODO: Add authentication headers
        const response = await fetch(`http://localhost:5000/api/admin/messages`);
        if (!response.ok) {
          throw new Error(`Failed to fetch messages (status: ${response.status})`);
        }
        const data = await response.json();
        if (Array.isArray(data)) {
          setMessages(data);
        } else {
          throw new Error("Invalid data format received");
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (isAdmin) { // Only fetch if user is admin
        fetchMessages();
    }
  }, [isAdmin]);

  const handleMarkAsRead = async (messageId: number, currentStatus: boolean) => {
    const newStatus = !currentStatus;
    try {
        // TODO: Add authentication headers
        const response = await fetch(`http://localhost:5000/api/admin/messages/${messageId}/read`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ is_read: newStatus }),
        });
        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || `Failed to update read status (status: ${response.status})`);
        }
        const updatedMessage = await response.json();
        setMessages(messages.map(m => m.id === messageId ? updatedMessage : m));
        // alert(`Message ${newStatus ? 'marked as read' : 'marked as unread'}.`); // TODO: Use notification
    } catch (err: any) {
        setError(`Error updating read status for message ${messageId}: ${err.message}`);
        alert(`Error updating read status: ${err.message}`); // TODO: Use notification
    }
  };

  const handleDeleteMessage = async (messageId: number) => {
    if (!confirm(`Are you sure you want to delete message ID ${messageId}?`)) { // TODO: Use modal and translate
        return;
    }
    try {
        // TODO: Add authentication headers
        const response = await fetch(`http://localhost:5000/api/admin/messages/${messageId}`, {
            method: "DELETE",
        });
        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || `Failed to delete message (status: ${response.status})`);
        }
        setMessages(messages.filter(m => m.id !== messageId));
        alert("Message deleted successfully."); // TODO: Use notification
    } catch (err: any) {
        setError(err.message);
        alert(`Error deleting message: ${err.message}`); // TODO: Use notification
    }
  };


  if (authLoading || loading) {
    return <p className="text-center py-10">Loading messages...</p>; // TODO: Translate
  }

  if (!isAdmin) {
    return <p className="text-center py-10 text-destructive">Access Denied.</p>; // TODO: Translate
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-primary">Manage Messages</h1> {/* TODO: Translate */}

      {error && <p className="text-center text-destructive">Error: {error}</p>} {/* TODO: Translate */}

      {/* Messages Table */}
      <div className="bg-card p-4 rounded-lg shadow-md border border-border overflow-x-auto">
        <table className="w-full text-sm text-left text-foreground">
          <thead className="text-xs text-muted-foreground uppercase bg-secondary">
            <tr>
              <th scope="col" className="px-6 py-3">ID</th>
              <th scope="col" className="px-6 py-3">Sender ID</th>
              <th scope="col" className="px-6 py-3">Receiver ID</th>
              <th scope="col" className="px-6 py-3">Subject</th>
              <th scope="col" className="px-6 py-3">Date</th>
              <th scope="col" className="px-6 py-3">Read</th>
              <th scope="col" className="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {messages.length > 0 ? (
              messages.map((message) => (
                <tr key={message.id} className={`bg-card border-b border-border/50 hover:bg-muted/50 ${!message.is_read ? 'font-semibold' : ''}`}>
                  <td className="px-6 py-4">{message.id}</td>
                  <td className="px-6 py-4">{message.sender_id ?? "Contact Form"}</td>
                  <td className="px-6 py-4">{message.receiver_id ?? "Admin"}</td>
                  <td className="px-6 py-4 truncate max-w-xs">{message.subject || "(No Subject)"}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{new Date(message.created_at).toLocaleString()}</td>
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={message.is_read}
                      onChange={() => handleMarkAsRead(message.id, message.is_read)}
                      className="form-checkbox h-4 w-4 text-primary border-input rounded focus:ring-primary"
                    />
                  </td>
                  <td className="px-6 py-4 flex space-x-2 whitespace-nowrap">
                    {/* TODO: Add View Details/Reply Modal/Page */}
                    <button className="text-blue-600 hover:underline text-xs">View</button> {/* TODO: Translate */}
                    <button onClick={() => handleDeleteMessage(message.id)} className="text-red-600 hover:underline text-xs">Delete</button> {/* TODO: Translate */}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="px-6 py-4 text-center text-muted-foreground">No messages found.</td> {/* TODO: Translate */}
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

