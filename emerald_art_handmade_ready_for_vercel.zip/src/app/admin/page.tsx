// src/app/admin/page.tsx
"use client";

import React from "react";
import Link from "next/link";
// import { useTranslations } from "next-intl"; // Add later when translations are added
// import { useAuth } from "@/context/AuthContext"; // Add later for role checking

export default function AdminDashboardPage() {
  // const t = useTranslations("AdminDashboard"); // Add later
  // const { user, loading } = useAuth(); // Add later

  // --- Placeholder for admin check ---
  const isAdmin = true; // Replace with actual role check from user context
  const loading = false; // Simulate auth loading
  // --- End Placeholder ---

  if (loading) {
    return <p className="text-center py-10">Loading...</p>; // TODO: Translate
  }

  if (!isAdmin) {
    // TODO: Redirect non-admins or show an error message
    return <p className="text-center py-10 text-destructive">Access Denied. Admins only.</p>; // TODO: Translate
  }

  const adminSections = [
    { href: "/admin/products", title: "Manage Products", description: "Add, edit, or remove products." }, // TODO: Translate
    { href: "/admin/orders", title: "Manage Orders", description: "View and update order statuses." }, // TODO: Translate
    { href: "/admin/users", title: "Manage Users", description: "View and manage user accounts." }, // TODO: Translate
    { href: "/admin/messages", title: "Manage Messages", description: "View and respond to user messages." }, // TODO: Translate
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-semibold text-primary">Admin Dashboard</h1> {/* TODO: Translate */}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {adminSections.map((section) => (
          <Link key={section.href} href={section.href} className="block bg-card p-6 rounded-lg shadow-md border border-border hover:shadow-lg hover:border-primary transition-all">
            <h2 className="text-xl font-semibold mb-2 text-foreground">{section.title}</h2>
            <p className="text-muted-foreground text-sm">{section.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

