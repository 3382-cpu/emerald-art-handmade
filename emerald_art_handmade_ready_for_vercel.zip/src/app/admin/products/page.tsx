// src/app/admin/products/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
// import { useTranslations, useLocale } from "next-intl"; // Add later
// import { useAuth } from "@/context/AuthContext"; // Add later for role checking

// Define Product interface (matching backend)
interface Product {
  id: number;
  name: string;
  description: string;
  price_usd: number;
  image_urls: string;
  available_colors: string;
  category?: string;
  stock_quantity?: number; // Assuming stock is managed
  created_at?: string;
  updated_at?: string;
}

export default function AdminProductsPage() {
  // const t = useTranslations("AdminProducts"); // Add later
  // const locale = useLocale(); // Add later
  // const { user, loading: authLoading } = useAuth(); // Add later

  // --- Placeholder for admin check ---
  const isAdmin = true; // Replace with actual role check
  const authLoading = false;
  // --- End Placeholder ---

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Fetch products from the backend API
    const fetchProducts = async () => {
      setLoading(true);
      setError(null);
      try {
        // TODO: Add authentication headers if required by the API
        const response = await fetch(`http://localhost:5000/api/products`); // Fetch all products
        if (!response.ok) {
          throw new Error(`Failed to fetch products (status: ${response.status})`);
        }
        const data = await response.json();
        if (Array.isArray(data)) {
          setProducts(data);
        } else {
          throw new Error("Invalid data format received");
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (isAdmin) { // Only fetch if user is admin
        fetchProducts();
    }
  }, [isAdmin]); // Re-fetch if admin status changes (though unlikely)

  const handleDeleteProduct = async (productId: number) => {
    if (!confirm(`Are you sure you want to delete product ID ${productId}?`)) { // TODO: Use a modal and translate
      return;
    }
    try {
      // TODO: Add authentication headers
      const response = await fetch(`http://localhost:5000/api/admin/products/${productId}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || `Failed to delete product (status: ${response.status})`);
      }
      // Remove product from state
      setProducts(products.filter(p => p.id !== productId));
      alert("Product deleted successfully."); // TODO: Use a notification system
    } catch (err: any) {
      setError(err.message);
      alert(`Error deleting product: ${err.message}`); // TODO: Use a notification system
    }
  };

  if (authLoading || loading) {
    return <p className="text-center py-10">Loading...</p>; // TODO: Translate
  }

  if (!isAdmin) {
    return <p className="text-center py-10 text-destructive">Access Denied.</p>; // TODO: Translate
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-primary">Manage Products</h1> {/* TODO: Translate */}
        <Link href="/admin/products/new" className="bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-semibold hover:bg-primary/90 transition-colors">
          Add New Product {/* TODO: Translate */}
        </Link>
      </div>

      {error && <p className="text-center text-destructive">Error: {error}</p>} {/* TODO: Translate */}

      {/* Products Table */}
      <div className="bg-card p-4 rounded-lg shadow-md border border-border overflow-x-auto">
        <table className="w-full text-sm text-left text-foreground">
          <thead className="text-xs text-muted-foreground uppercase bg-secondary">
            <tr>
              <th scope="col" className="px-6 py-3">ID</th>
              <th scope="col" className="px-6 py-3">Name</th>
              <th scope="col" className="px-6 py-3">Price (USD)</th>
              <th scope="col" className="px-6 py-3">Stock</th>
              <th scope="col" className="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.length > 0 ? (
              products.map((product) => (
                <tr key={product.id} className="bg-card border-b border-border/50 hover:bg-muted/50">
                  <td className="px-6 py-4 font-medium">{product.id}</td>
                  <td className="px-6 py-4">{product.name}</td>
                  <td className="px-6 py-4">${product.price_usd.toFixed(2)}</td>
                  <td className="px-6 py-4">{product.stock_quantity ?? "N/A"}</td>
                  <td className="px-6 py-4 flex space-x-2">
                    <Link href={`/admin/products/edit/${product.id}`} className="text-blue-600 hover:underline text-xs">Edit</Link> {/* TODO: Translate */}
                    <button onClick={() => handleDeleteProduct(product.id)} className="text-red-600 hover:underline text-xs">Delete</button> {/* TODO: Translate */}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="px-6 py-4 text-center text-muted-foreground">No products found.</td> {/* TODO: Translate */}
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

