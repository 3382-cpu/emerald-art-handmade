// src/app/admin/products/edit/[id]/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
// import { useTranslations } from "next-intl"; // Add later
// import { useAuth } from "@/context/AuthContext"; // Add later for role checking

// Define Product interface (matching backend)
interface Product {
  id: number;
  name: string;
  description: string;
  price_usd: number;
  image_urls: string;
  available_colors: string;
  category?: string;
  stock_quantity?: number;
}

export default function AdminEditProductPage() {
  // const t = useTranslations("AdminEditProduct"); // Add later
  const router = useRouter();
  const params = useParams();
  const productId = params.id;
  // const { user, loading: authLoading } = useAuth(); // Add later

  // --- Placeholder for admin check ---
  const isAdmin = true; // Replace with actual role check
  const authLoading = false;
  // --- End Placeholder ---

  // Form state
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [priceUsd, setPriceUsd] = useState("");
  const [stockQuantity, setStockQuantity] = useState("");
  const [availableColors, setAvailableColors] = useState(""); // Comma-separated string
  const [imageUrls, setImageUrls] = useState(""); // Comma-separated string
  const [category, setCategory] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true); // Start loading as we fetch data
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!productId || !isAdmin) return;

    const fetchProduct = async () => {
      setLoading(true);
      setError(null);
      try {
        // TODO: Add authentication headers
        const response = await fetch(`http://localhost:5000/api/products/${productId}`);
        if (!response.ok) {
          throw new Error(`Failed to fetch product (status: ${response.status})`);
        }
        const data: Product = await response.json();

        // Populate form fields
        setName(data.name || "");
        setDescription(data.description || "");
        setPriceUsd(data.price_usd?.toString() || "");
        setStockQuantity(data.stock_quantity?.toString() || "");
        setCategory(data.category || "");

        // Convert JSON arrays back to comma-separated strings for input fields
        try {
          const colorsArray = JSON.parse(data.available_colors || "[]");
          setAvailableColors(Array.isArray(colorsArray) ? colorsArray.join(", ") : "");
        } catch { setAvailableColors(""); }

        try {
          const urlsArray = JSON.parse(data.image_urls || "[]");
          setImageUrls(Array.isArray(urlsArray) ? urlsArray.join(", ") : "");
        } catch { setImageUrls(""); }

      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [productId, isAdmin]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);

    // Basic validation
    if (!name || !priceUsd || !stockQuantity) {
      setError("Name, Price, and Stock Quantity are required."); // TODO: Translate
      setSaving(false);
      return;
    }

    try {
      // Prepare data for API
      const productData = {
        name,
        description,
        price_usd: parseFloat(priceUsd),
        stock_quantity: parseInt(stockQuantity, 10),
        available_colors: JSON.stringify(availableColors.split(",").map(s => s.trim()).filter(Boolean)),
        image_urls: JSON.stringify(imageUrls.split(",").map(s => s.trim()).filter(Boolean)),
        category: category || null,
      };

      // TODO: Add authentication headers
      const response = await fetch(`http://localhost:5000/api/admin/products/${productId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(productData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || `Failed to update product (status: ${response.status})`);
      }

      alert("Product updated successfully!"); // TODO: Use notification system
      router.push("/admin/products"); // Redirect back to the products list

    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (authLoading || loading) {
    return <p className="text-center py-10">Loading product data...</p>; // TODO: Translate
  }

  if (!isAdmin) {
    return <p className="text-center py-10 text-destructive">Access Denied.</p>; // TODO: Translate
  }

  if (error && !loading) {
     return <p className="text-center py-10 text-destructive">Error loading product: {error}</p>; // TODO: Translate
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-semibold text-primary">Edit Product (ID: {productId})</h1> {/* TODO: Translate */}

      <form onSubmit={handleSubmit} className="bg-card p-6 rounded-lg shadow-md border border-border space-y-4">
        {/* Name */}
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1">Name</label> {/* TODO: Translate */}
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
          />
        </div>

        {/* Description */}
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-foreground mb-1">Description</label> {/* TODO: Translate */}
          <textarea
            id="description"
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
          />
        </div>

        {/* Price & Stock */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="priceUsd" className="block text-sm font-medium text-foreground mb-1">Price (USD)</label> {/* TODO: Translate */}
            <input
              type="number"
              id="priceUsd"
              value={priceUsd}
              onChange={(e) => setPriceUsd(e.target.value)}
              required
              step="0.01"
              min="0"
              className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
            />
          </div>
          <div>
            <label htmlFor="stockQuantity" className="block text-sm font-medium text-foreground mb-1">Stock Quantity</label> {/* TODO: Translate */}
            <input
              type="number"
              id="stockQuantity"
              value={stockQuantity}
              onChange={(e) => setStockQuantity(e.target.value)}
              required
              step="1"
              min="0"
              className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
            />
          </div>
        </div>

        {/* Colors */}
        <div>
          <label htmlFor="availableColors" className="block text-sm font-medium text-foreground mb-1">Available Colors (comma-separated)</label> {/* TODO: Translate */}
          <input
            type="text"
            id="availableColors"
            value={availableColors}
            onChange={(e) => setAvailableColors(e.target.value)}
            className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
            placeholder="e.g., Red, Blue, Green"
          />
        </div>

        {/* Image URLs */}
        <div>
          <label htmlFor="imageUrls" className="block text-sm font-medium text-foreground mb-1">Image URLs (comma-separated)</label> {/* TODO: Translate */}
          <input
            type="text"
            id="imageUrls"
            value={imageUrls}
            onChange={(e) => setImageUrls(e.target.value)}
            className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
            placeholder="e.g., /image1.jpg, /image2.png"
          />
        </div>

        {/* Category */}
        <div>
          <label htmlFor="category" className="block text-sm font-medium text-foreground mb-1">Category</label> {/* TODO: Translate */}
          <input
            type="text"
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
            placeholder="e.g., Bouquets, Mirrors"
          />
        </div>

        {error && (
          <p className="text-sm text-destructive text-center">Error: {error}</p> // TODO: Translate
        )}

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={() => router.back()} // Go back to previous page
            className="bg-muted text-muted-foreground px-4 py-2 rounded-md text-sm font-semibold hover:bg-muted/80 transition-colors"
          >
            Cancel {/* TODO: Translate */}
          </button>
          <button
            type="submit"
            disabled={saving}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-md text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50"
          >
            {saving ? "Saving..." : "Save Changes"} {/* TODO: Translate */}
          </button>
        </div>
      </form>
    </div>
  );
}

