// src/app/profile/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useTranslations, useLocale } from "next-intl"; // Import hooks
// import { useAuth } from "@/context/AuthContext"; // Assuming an AuthContext exists later

// Define interfaces (assuming they are correct)
interface OrderItem {
    id: number;
    order_id: number;
    product_id: number;
    quantity: number;
    price_at_purchase: number;
}

interface Order {
    id: number;
    user_id: number;
    status: string;
    total_amount_usd: number;
    shipping_address: string;
    created_at: string;
    updated_at: string;
    items: OrderItem[];
}

interface Message {
    id: number;
    sender_id: number;
    receiver_id: number;
    subject: string | null;
    body: string;
    is_read: boolean;
    created_at: string;
    order_id: number | null;
}

interface User {
    id: number;
    username: string;
    email: string;
    role: string;
    created_at: string;
}

export default function ProfilePage() {
  const t = useTranslations("ProfilePage"); // Use translations
  const locale = useLocale(); // Get current locale
  // const { user, loading: authLoading, logout } = useAuth();

  // --- Placeholder for user data ---
  const [authLoading, setAuthLoading] = useState(false);
  const [user, setUser] = useState<User | null>({
      id: 1,
      username: "testuser",
      email: "test@example.com",
      role: "customer",
      created_at: new Date().toISOString(),
  });
  const logout = () => { setUser(null); alert("Logged out (simulation)"); };
  // --- End Placeholder ---

  const [orders, setOrders] = useState<Order[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      setLoadingOrders(true);
      setLoadingMessages(true);
      setError(null);
      try {
        // Fetch Orders
        const ordersRes = await fetch(`http://localhost:5000/api/orders?user_id=${user.id}`); // TODO: Add auth token header
        if (!ordersRes.ok) {
          throw new Error(`Failed to fetch orders (status: ${ordersRes.status})`);
        }
        const ordersData = await ordersRes.json();
        if (Array.isArray(ordersData)) setOrders(ordersData);
        setLoadingOrders(false);

        // Fetch Messages
        const messagesRes = await fetch(`http://localhost:5000/api/messages?user_id=${user.id}`); // TODO: Add auth token header
        if (!messagesRes.ok) {
          throw new Error(`Failed to fetch messages (status: ${messagesRes.status})`);
        }
        const messagesData = await messagesRes.json();
         if (Array.isArray(messagesData)) setMessages(messagesData);
        setLoadingMessages(false);

      } catch (err: any) {
        setError(err.message);
        setLoadingOrders(false);
        setLoadingMessages(false);
      }
    };

    fetchData();
  }, [user]);

  if (authLoading) {
    return <p className="text-center py-10">{t("loading")}</p>;
  }

  if (!user) {
    // TODO: Redirect to login page
    return <p className="text-center py-10">{t("pleaseLogin")}</p>;
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-12">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold text-primary">{t("title")}</h1>
        <button
          onClick={logout}
          className="bg-destructive text-destructive-foreground px-4 py-2 rounded-md text-sm font-semibold hover:bg-destructive/90 transition-colors"
        >
          {t("logoutButton")}
        </button>
      </div>

      {/* User Info Section */}
      <div className="bg-card p-6 rounded-lg shadow-md border border-border">
        <p><strong>{t("username")}</strong> {user.username}</p>
        <p><strong>{t("email")}</strong> {user.email}</p>
        <p><strong>{t("memberSince")}</strong> {new Date(user.created_at).toLocaleDateString(locale)}</p> {/* Use locale for date format */}
      </div>

      {error && <p className="text-center text-destructive">{t("errorPrefix")}{error}</p>}

      {/* Orders Section */}
      <section>
        <h2 className="text-2xl font-semibold mb-4 text-foreground">{t("ordersTitle")}</h2>
        {loadingOrders ? (
          <p>{t("loading")}</p>
        ) : orders.length > 0 ? (
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="bg-card p-4 rounded-lg shadow-sm border border-border/50">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p><strong>{t("orderId")}:</strong> {order.id}</p>
                    <p><strong>{t("orderDate")}:</strong> {new Date(order.created_at).toLocaleString(locale)}</p> {/* Use locale */} 
                  </div>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${order.status === "delivered" ? "bg-green-100 text-green-800" : order.status === "cancelled" ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"}`}>
                    {/* TODO: Translate order status if needed */}
                    {order.status}
                  </span>
                </div>
                <p className="text-right font-semibold">{t("orderTotal")}: ${order.total_amount_usd.toFixed(2)}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">{t("noOrders")}</p>
        )}
      </section>

      {/* Messages Section */}
      <section>
        <h2 className="text-2xl font-semibold mb-4 text-foreground">{t("messagesTitle")}</h2>
        {loadingMessages ? (
          <p>{t("loading")}</p>
        ) : messages.length > 0 ? (
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`bg-card p-4 rounded-lg shadow-sm border border-border/50 ${!message.is_read && message.receiver_id === user.id ? "border-primary" : ""}`}>
                <p><strong>{t("messageSubject")}:</strong> {message.subject || "(No Subject)"}</p>
                <p className="text-sm text-muted-foreground"><strong>{message.sender_id === user.id ? t("messageTo") : t("messageFrom")}:</strong> User {message.sender_id === user.id ? message.receiver_id : message.sender_id}</p>
                <p className="mt-2 text-sm">{message.body}</p>
                <p className="text-xs text-muted-foreground/70 mt-2 text-right">{new Date(message.created_at).toLocaleString(locale)}</p> {/* Use locale */} 
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">{t("noMessages")}</p>
        )}
      </section>

    </div>
  );
}

