// src/app/contact/page.tsx
"use client";

import React, { useState } from "react";
import { useTranslations } from "next-intl"; // Import hook

export default function ContactPage() {
  const t = useTranslations("ContactPage"); // Use translations

  // State for form fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState(""); // For submission status messages

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus(t("sending")); // Use translated sending status
    setError(null);

    try {
      // TODO: Implement actual form submission logic here
      // Call the backend /api/messages endpoint
      const response = await fetch(`http://localhost:5000/api/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        // Assuming sender_id is null for anonymous messages, or get from auth context
        body: JSON.stringify({ subject: `Contact Form: ${name}`, body: message, email: email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || t("errorMsg"));
      }

      setStatus(t("successMsg"));
      // Optionally clear form
      setName("");
      setEmail("");
      setMessage("");

    } catch (err: any) {
      setError(err.message || t("errorMsg"));
      setStatus(""); // Clear status on error
    } 
    // Removed finally block to keep status message visible
  };

  // State for backend error message
  const [error, setError] = useState<string | null>(null);


  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-semibold text-center text-primary">{t("title")}</h1>
      <p className="text-center text-muted-foreground max-w-xl mx-auto">{t("intro")}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
        {/* Contact Form */}
        <div className="bg-card p-6 rounded-lg shadow-md border border-border">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1">{t("nameLabel")}</label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-foreground mb-1">{t("emailLabel")}</label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-foreground mb-1">{t("messageLabel")}</label>
              <textarea
                id="message"
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                className="w-full px-3 py-2 border border-input rounded-md bg-background focus:ring-primary focus:border-primary"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-primary text-primary-foreground px-6 py-2 rounded-md font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50"
              disabled={status === t("sending")}
            >
              {status === t("sending") ? t("sending") : t("submitButton")}
            </button>
            {/* Display backend error or success message */}
            {error && (
                 <p className="text-sm text-center text-destructive">{error}</p>
            )}
            {status && status !== t("sending") && !error && (
              <p className={`text-sm text-center ${status === t("successMsg") ? "text-green-600" : "text-destructive"}`}>
                {status}
              </p>
            )}
          </form>
        </div>

        {/* Contact Information */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-primary">{t("contactInfoTitle")}</h2>
          <p className="text-muted-foreground">{t("emailInfo")}</p>
          <p className="text-muted-foreground">{t("phoneInfo")}</p>
          <p className="text-muted-foreground">{t("addressInfo")}</p>
          {/* Add map or other details if needed */}
        </div>
      </div>
    </div>
  );
}

