// src/app/register/page.tsx
"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl"; // Import hook
// import { useRouter } from "next/navigation";
// import { useAuth } from "@/context/AuthContext";

export default function RegisterPage() {
  const t = useTranslations("RegisterPage"); // Use translations
  // const router = useRouter();
  // const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError(t("passwordMismatch")); // Use translated error
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`http://localhost:5000/api/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        // Use generic error message or specific one from backend if available
        throw new Error(data.error || `Failed to register (status: ${response.status})`);
      }

      console.log("Registration successful:", data);
      // TODO: Optionally auto-login & redirect
      alert("Registration successful! Please login. (Redirect/State update needed)");

    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-card p-8 rounded-lg shadow-md border border-border">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-primary">
            {t("title")}
          </h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="rounded-md shadow-sm -space-y-px">
            <div>
              <label htmlFor="username" className="sr-only">{t("usernameLabel")}</label>
              <input
                id="username"
                name="username"
                type="text"
                autoComplete="username"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-input placeholder-muted-foreground text-foreground rounded-t-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
                placeholder={t("usernameLabel")}
              />
            </div>
            <div>
              <label htmlFor="email-address" className="sr-only">{t("emailLabel")}</label>
              <input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-input placeholder-muted-foreground text-foreground focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
                placeholder={t("emailLabel")}
              />
            </div>
            <div>
              <label htmlFor="password" className="sr-only">{t("passwordLabel")}</label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="new-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-input placeholder-muted-foreground text-foreground focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
                placeholder={t("passwordLabel")}
              />
            </div>
            <div>
              <label htmlFor="confirm-password" className="sr-only">{t("confirmPasswordLabel")}</label>
              <input
                id="confirm-password"
                name="confirm-password"
                type="password"
                autoComplete="new-password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-input placeholder-muted-foreground text-foreground rounded-b-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
                placeholder={t("confirmPasswordLabel")}
              />
            </div>
          </div>

          {error && (
            <p className="text-sm text-destructive text-center">{error}</p>
          )}

          <div>
            <button
              type="submit"
              disabled={loading}
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-primary-foreground bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50"
            >
              {loading ? t("registering") : t("registerButton")}
            </button>
          </div>
        </form>
        <div className="text-sm text-center">
          <span className="text-muted-foreground">{t("loginPrompt")} </span>
          <Link href="/login" className="font-medium text-primary hover:text-primary/80">
            {t("loginLink")}
          </Link>
        </div>
      </div>
    </div>
  );
}

